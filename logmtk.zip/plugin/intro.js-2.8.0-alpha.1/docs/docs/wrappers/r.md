---
layout: doc
title: R
categories: wrappers
permalink: /wrappers/R
---

You can use IntroJs with [R](https://cran.r-project.org/) for [Shiny applications](http://shiny.rstudio.com/) with the [rintrojs package on CRAN](https://cran.r-project.org/web/packages/rintrojs/).

Github: [https://github.com/carlganz/rintrojs](https://github.com/carlganz/rintrojs)

*Do you know a project that we didn't mention here? Please update the documentation on Github or [email](mailto:support@introjs.com) us.*
